#include <windows.h>
#include "BaseType.h"
#include "Utility.hpp"
#include <map>
#include <sstream> // wostringstream
#include "character_inform_manager.h"

#define manager_depot char_man_depot.get_depot()

class in_game
{

public:
	in_game();
	~in_game();

	void attach(HWND);

	void draw(HDC);

	void Input(DWORD);
	void Update(DWORD);


	void Load_game_map(LPCTSTR szFileName);



private:

	HBITMAP hBitmap;
	Rect rcSrc;
	Rect rcDest;

	HWND hOwner;

	Point ptMouse;
	Point temp_Position;

	character_inform* character_inform_box;


};

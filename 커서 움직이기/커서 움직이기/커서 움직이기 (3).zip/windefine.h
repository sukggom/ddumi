﻿#pragma once

#include <windows.h>
#include <tchar.h>
#include <stdlib.h> // rand, srand
#include <time.h> // time
#include <sstream> // wostringstream
#include "BaseType.h"
#include "Utility.hpp"
#include "chars.h"


LRESULT CALLBACK WndProc(HWND,UINT,WPARAM,LPARAM);
